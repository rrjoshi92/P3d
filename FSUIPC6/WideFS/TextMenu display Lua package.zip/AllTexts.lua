-- Set these values to suit your display needs

TextLeft = 1024
TextTop1 = 5
TextTop2 = 135
TextWidth = 1018
TextHeight1 = 130
TextHeight2 = 633

-- The rest of this program can stay as it is
-- unless you want to change the way it cycles
-- through available displays. Then you need to
-- change the line
-- "event.offsetmask(0x66E0, 1, "UB", "cyclestate")"
-- just below. You can use a different offset, or
-- or a button, or keypress, as you wish.

winstate = 0
nowFile = 0
nowWthr = 0
nowWind = 0
nowMenu = 0

statefile = 0
statemenu = 0	
statewthr = 0	
statewind = 0

function teststate() 
	if winstate == 1 then
		ext.state("File", EXT_NRML)
	else
		ext.state("File", EXT_HIDE)
	end
	
	if winstate == 2 then
		ext.state("SimC Menu", EXT_NRML)
	else
		ext.state("SimC Menu", EXT_HIDE)
	end
	
	if winstate == 3 then
		ext.state("SimC Weather", EXT_NRML)
	else
		ext.state("SimC Weather", EXT_HIDE)
	end
	
	if winstate == 0 then
		ext.state("SimC Window", EXT_NRML)
	else
		ext.state("SimC Window", EXT_HIDE)
	end
end

function cyclestate() 
	ctr = 0
	while ctr < 4  do
		winstate = winstate + 1
		if winstate > 3 then 
			winstate = 0
		end
		
		if  (((winstate == 0) and (nowWind ~= 0)) or
			((winstate == 1) and (nowFile ~= 0)) or
			((winstate == 2) and (nowMenu ~= 0)) or
			((winstate == 3) and (nowWthr ~= 0)))
		then
			break
		end
		ctr = ctr + 1
	end
	teststate()
end

ipc.writeUD(0x66E0, 0)
ipc.sleep(250)
teststate()

event.offsetmask(0x66E0, 1, "UB", "cyclestate")

-- #######################################################################
-- Operates special file display (aimed at Pilot2ATC conversion text)
-- Colour encoding is only applicable to Pilot2ATC conversation text file
atccolours = { 0xfff, 0xf00, 0x0f0, 0x99f, 0xff5}
--       white     Red           Green       Blue   others Gray
types = {"ATC: ", "Suggested: ", "Pilot: ",  "Info: " }

wFile = wnd.open("File", WND_FIXED,TextLeft,TextTop2,TextWidth,TextHeight2)
wnd.backcol(wFile, 0x000)
wnd.textcol(wFile, 0x0f0)
wnd.font(wFile, WND_ARIAL, 20, WND_BOLD)

function showfile(mtype, colour, scroll, delay, id, n, msgs)
	if n == 0 then 
		wnd.clear(wFile)
		statefile = 0
		ext.state("File", EXT_HIDE)
	else
		nowFile = 1
		statefile = 1
		if statemenu == 0 then
			winstate = 1
		end
		ext.state("File", EXT_NRML)
		i = 1
		while i <= n do
			colour = 1
			pos = nil
			while colour < 5 do
				pos = string.find(msgs[i], types[colour], 1, true)
				if pos then break end
				colour = colour + 1
			end
			if pos then
				pos = pos + string.len(types[colour])
			else 
				pos = 1
				colour = 5
			end
			
			wnd.textcol(wFile, atccolours[colour])
			wnd.text(wFile, -1, string.sub(msgs[i], pos))
			i = i+1
		end	
	end

	if (statefile == 0) then
		nowFile = 0
		cyclestate()
	end
end

ipc.sleep(2000)

event.textmenu(16, "showfile") -- 2 = SimC menu

-- #######################################################################
-- Operates SimC Menu display
wMenu = wnd.open("SimC Menu", WND_FIXED,TextLeft,TextTop2,TextWidth,TextHeight2)
wnd.backcol(wMenu, 0x3EF)
wnd.textcol(wMenu, 0x000)
wnd.font(wMenu, WND_ARIAL, 20, WND_BOLD)

function menu(mtype, colour, scroll, delay, id, n, msgs)
	wnd.clear(wMenu)
	if (n == 0) or ((n == 1) and (string.byte(msgs[1]) == 0)) then 
		statemenu = 0
		ext.state("SimC Menu", EXT_HIDE)
	else
		ipc.writeUB(0x66E1, 2)
		wnd.clear(wMenu)
		statemenu = 1
		winstate = 2
		ext.state("SimC Menu", EXT_NRML)
		ipc.set("ReqDisp",2)
		wnd.text(wMenu, " " .. msgs[1])
		wnd.text(wMenu, " ")
		if (n > 1) then
			wnd.text(wMenu, " " .. msgs[2])
			wnd.text(wMenu, " ")
		end
		i = 3
		j = 1
		while i <= n do
			wnd.text(wMenu, " " .. j .. " - " .. msgs[i])
			i = i + 1
			j = j + 1
			if (j > 9) then 
				j = 0
			end
		end
	end
	
	nowMenu = statemenu
	if (statemenu == 0) then
		cyclestate()
	end
end

event.textmenu(2, "menu") -- 2 = SimC menu
	
-- #######################################################################
-- Operates ActiveSky plan weather summary display
wWthr = wnd.open("SimC Weather", WND_FIXED,TextLeft,TextTop2,TextWidth,TextHeight2)
wnd.backcol(wWthr, 0xfff)
wnd.textcol(wWthr, 0x000)
wnd.font(wWthr, WND_ARIAL, 20, WND_BOLD)

function wthr(mtype, colour, scroll, delay, id, n, msgs)
	wnd.clear(wWthr)	
	if (n == 0) or ((n == 1) and (string.byte(msgs[1]) == 0)) then 
		statewthr = 0
		ext.state("SimC Weather", EXT_HIDE)
	else
		ipc.writeUB(0x66E1, 3)
		nowWthr =1
		statewthr = 1
		winstate = 3
		ext.state("SimC Weather", EXT_NRML)
		wnd.clear(wWthr)
		wnd.text(wWthr, " " .. msgs[1])
		wnd.text(wWthr, " ")
		if (n > 1) then
			wnd.text(wWthr, " " .. msgs[2])
			wnd.text(wWthr, " ")
		end
		i = 3
		j = 1
		while i <= n do
			wnd.text(wWthr, " " .. j .. " - " .. msgs[i])
			i = i + 1
			j = j + 1
			if (j > 9) then 
				j = 0
			end
		end
	end
	
	if (statewthr == 0) then
		nowWthr = 0
		cyclestate()
	end
end

event.textmenu(8, "wthr") -- 2 = ASN Weather

-- #######################################################################
-- Operates SimC Message Window (lowest priority)
wWind = wnd.open("SimC Window", WND_FIXED,TextLeft,TextTop2,TextWidth,TextHeight2)
wnd.backcol(wWind, 0x88f)
wnd.textcol(wWind, 0x808)
wnd.font(wWind, WND_ARIAL, 20, WND_BOLD)

function wind(mtype, colour, scroll, delay, id, n, msgs)
	wnd.clear(wWind)
	if (n == 0) or ((n == 1) and (string.byte(msgs[1]) == 0)) then 
		statewind = 0
	else
		states = statefile + statewthr + statemenu
		if (states == 0) or (winstate == 0) then
			ext.state("SimC Window", EXT_NRML)
			winstate = 0
		end
		wnd.text(wWind, msgs[1])
		if (n > 1) then
			wnd.text(wWind,msgs[2])
		end
		statewind = 1
	end

	nowWind = statewind
	if (statewind == 0) then 
		cyclestate()
	end
end

event.textmenu(4, "wind") -- 4 = SimC message window

-- #######################################################################
-- Operates small SimC text display (always shown)
prevmsg = ""
time1 = 0
timeclear1 = 0

wText = wnd.open("SimC Text", WND_FIXED,TextLeft,TextTop1,TextWidth,TextHeight1)
wnd.backcol(wText, 0x777)
wnd.textcol(wText, 0x000)
wnd.font(wText, WND_ARIAL, 20, WND_BOLD)
ext.state("SimC Text", EXT_NRML)

function text(mtype, colour, scroll, delay, id, n, msgs)
	if (n == 0) or ((n == 1) and (string.byte(msgs[1]) == 0)) then 
		wnd.clear(wText)
		prevmsg = ""
	else
		if msgs[1] == prevmsg then
			wnd.clear(wText)
		end      
		prevmsg = msgs[1]
			
		wnd.text(wText, -1, msgs[1])
		if delay > 0.9 then
			timeclear1 = delay * 1000
			time1 = ipc.elapsedtime()
		end
	end
end

function time()
    val = ipc.elapsedtime()
	if time1 ~= 0 and ((val - time1) > timeclear1) then
	   	wnd.clear(wText)
		time1 = 0
	end
	
	teststate()
end	

event.textmenu(1, "text") -- 1 = SimC text
event.timer(500, "time")
