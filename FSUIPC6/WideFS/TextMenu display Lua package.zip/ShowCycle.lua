ipc.set("TextLeft", 0)
ipc.set("TextTop1", 0)
ipc.set("TextTop2", 130)
ipc.set("TextWidth", 1024)
ipc.set("TextHeight1", 130)
ipc.set("TextHeight2", 638)

function cyclestate() 
	ctr = 0
	winstate = ipc.get("ReqDisp")
	nowFile = ipc.get("FileSet")
	nowWthr = ipc.get("WthrSet")
	nowWind = ipc.get("WindSet")
	nowMenu = ipc.get("MenuSet")
	
	while ctr < 4  do
		winstate = winstate + 1
		if winstate > 3 then 
			winstate = 0
		end
		
		if  (((winstate == 0) and (nowWind ~= 0)) or
			((winstate == 1) and (nowFile ~= 0)) or
			((winstate == 2) and (nowMenu ~= 0)) or
			((winstate == 3) and (nowWthr ~= 0)))
		then
			break
		end
		ctr = ctr + 1
	end
	ipc.set("ReqDisp", winstate)
end

ipc.writeUW(0x66E0, 0)
ipc.set("WindSet", 0)
ipc.set("FileSet", 0)
ipc.set("MenuSet", 0)
ipc.set("WthrSet", 0)
ipc.set("ReqDisp", 0)

ipc.sleep(1500)

event.offsetmask(0x66E0, 1, "UB", "cyclestate")

	
