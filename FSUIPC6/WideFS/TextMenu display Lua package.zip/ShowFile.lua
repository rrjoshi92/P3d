-- Operates special file display (aimed at Pilot2ATC conversion text)

ipc.sleep(1000)

-- Colour encoding is only applicable to Pilot2ATC conversation text file
atccolours = { 0xfff, 0xf00, 0x0f0, 0x99f, 0xff5}
--       white     Red           Green       Blue   others Gray
types = {"ATC: ", "Suggested: ", "Pilot: ",  "Info: " }

LEFT = ipc.get("TextLeft")
TOP = ipc.get("TextTop2")
WIDTH = ipc.get("TextWidth")
HEIGHT = ipc.get("TextHeight2")
w1 = wnd.open("File", WND_FIXED,LEFT,TOP,WIDTH,HEIGHT)
wnd.backcol(w1, 0x000)
wnd.textcol(w1, 0x0f0)
wnd.font(w1, WND_ARIAL, 20, WND_BOLD)
state = false

function teststate() 
	winstate = ipc.get("ReqDisp")
	if winstate == 1 then
		if state == 0 then
			state = 1
			ext.state("File", EXT_NRML)
		end
	else
		if state ~= 0 then
			state = 0
			ext.state("File", EXT_HIDE)
		end
	end
end

teststate()


function showfile(mtype, colour, scroll, delay, id, n, msgs)
	if n == 0 then 
		wnd.clear(w1)
		state = 0
		ext.state("File", EXT_HIDE)
	else
		ipc.set("ReqDisp",1)
		state = 1
		ext.state("File", EXT_NRML)
		
		i = 1
		while i <= n do
			colour = 1
			pos = nil
			while colour < 5 do
				pos = string.find(msgs[i], types[colour], 1, true)
				if pos then break end
				colour = colour + 1
			end
			if pos then
				pos = pos + string.len(types[colour])
			else 
				pos = 1
				colour = 5
			end
			
			wnd.textcol(w1, atccolours[colour])
			wnd.text(w1, -1, string.sub(msgs[i], pos))
			i = i+1
		end	
	end
	ipc.set("FileSet", state)	
	if (state == 0) then 
		ipc.set("ReqDisp", 0)
		ipc.togglebitsUB(0x66E0, 1)
	end
end

ipc.sleep(2000)

event.textmenu(16, "showfile") -- 2 = SimC menu
event.offsetmask(0x66E0, 1, "UB", "teststate")
event.timer(500,"teststate")
