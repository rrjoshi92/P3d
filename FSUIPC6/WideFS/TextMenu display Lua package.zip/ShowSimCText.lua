-- Operates small SimC text display (always shown)

ipc.sleep(1000)
prevmsg = ""
time1 = 0
timeclear1 = 0

LEFT = ipc.get("TextLeft")
TOP = ipc.get("TextTop1")
WIDTH = ipc.get("TextWidth")
HEIGHT = ipc.get("TextHeight1")
w1 = wnd.open("SimC Text", WND_FIXED,LEFT,TOP,WIDTH,HEIGHT)
wnd.backcol(w1, 0x777)
wnd.textcol(w1, 0x000)
wnd.font(w1, WND_ARIAL, 20, WND_BOLD)
ext.state("SimC Text", EXT_NRML)

function text(mtype, colour, scroll, delay, id, n, msgs)
	if (n == 0) or ((n == 1) and (string.byte(msgs[1]) == 0)) then 
		wnd.clear(w1)
		prevmsg = ""
	else
		if msgs[1] == prevmsg then
			wnd.clear(w1)
		end      
		prevmsg = msgs[1]
			
		wnd.text(w1, -1, msgs[1])
		if delay > 0.9 then
			timeclear1 = delay * 1000
			time1 = ipc.elapsedtime()
		end
	end
end

function time()
    val = ipc.elapsedtime()
	if time1 ~= 0 and ((val - time1) > timeclear1) then
	   	wnd.clear(w1)
		time1 = 0
	end
end	

event.textmenu(1, "text") -- 1 = SimC text
event.timer(500, "time")
