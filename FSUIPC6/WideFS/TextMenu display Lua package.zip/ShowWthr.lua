-- Operates ActiveSky plan weather summary display

ipc.sleep(1000)
prevmsg = ""

LEFT = ipc.get("TextLeft")
TOP = ipc.get("TextTop2")
WIDTH = ipc.get("TextWidth")
HEIGHT = ipc.get("TextHeight2")
w1 = wnd.open("SimC Weather", WND_FIXED,LEFT,TOP,WIDTH,HEIGHT)
wnd.backcol(w1, 0xfff)
wnd.textcol(w1, 0x000)
wnd.font(w1, WND_ARIAL, 20, WND_BOLD)
state = false

function teststate() 
	winstate = ipc.get("ReqDisp")
	if winstate == 3 then
		if state == 0 then 
			state = 1
			ext.state("SimC Weather", EXT_NRML)
		end
	else
		if state ~= 0 then
			state = 0
			ext.state("SimC Weather", EXT_HIDE)
		end
	end
end

teststate()


function wthr(mtype, colour, scroll, delay, id, n, msgs)
	wnd.clear(w1)
	winstates = ipc.readUB(0x66E0)
	if (n == 0) or ((n == 1) and (string.byte(msgs[1]) == 0)) then 
		prevmsg = ""
		state = 0
		ext.state("SimC Weather", EXT_HIDE)
	else
		ipc.set("ReqDisp",3)
		state = 1
		ext.state("SimC Weather", EXT_NRML)
		--ipc.log("Wthr shown")
		wnd.clear(w1)
		wnd.text(w1, " " .. msgs[1])
		wnd.text(w1, " ")
		if (n > 1) then
			wnd.text(w1, " " .. msgs[2])
			wnd.text(w1, " ")
		end
		i = 3
		j = 1
		while i <= n do
			wnd.text(w1, " " .. j .. " - " .. msgs[i])
			i = i + 1
			j = j + 1
			if (j > 9) then 
				j = 0
			end
		end
	end
	ipc.set("WthrSet", state)
	if (state == 0) then 
		ipc.set("ReqDisp", 0)
		ipc.togglebitsUB(0x66E0, 1)
	end
end

ipc.sleep(2000)
event.textmenu(8, "wthr") -- 2 = ASN Weather
event.offsetmask(0x66E0, 1, "UB", "teststate")
event.timer(500,"teststate")
